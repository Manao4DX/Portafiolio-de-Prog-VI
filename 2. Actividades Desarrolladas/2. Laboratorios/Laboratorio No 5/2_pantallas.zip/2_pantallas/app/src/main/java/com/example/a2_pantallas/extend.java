package com.example.a2_pantallas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;
import android.widget.Switch;
import android.view.View;

public class extend extends AppCompatActivity {

    private Switch switch1, switch2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extend);

        switch1=findViewById(R.id.switch1);
        switch2=findViewById(R.id.switch2);
    }

    public void verificar(View view){
        if(switch1.isChecked())
            Toast.makeText(this, "datos moviles activados", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "dates moviles desactivados", Toast.LENGTH_SHORT).show();
        if(switch2.isChecked())
            Toast.makeText(this, "Wi-Fi activados", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "Wi-Fi desactivados", Toast.LENGTH_SHORT).show();
    }
    public void salir(View view){
        finish();
    }

}