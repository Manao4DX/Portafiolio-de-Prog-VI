package com.example.a2_pantallas;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Spinn extends AppCompatActivity {
    private Spinner spinner1;
    private EditText et1, et2;
    private TextView tv1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1=findViewById(R.id.et1);
        et2=findViewById(R.id.et2);
        tv1=findViewById(R.id.tv1);

        spinner1=findViewById(R.id.spinner1);
        String[]opciones={"sumar","restar","multiplicar","dividir"};
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, opciones);
        spinner1.setAdapter(adapter);
    }

    public void operar(View view){
        String valor1=et1.getText().toString();
        String valor2=et2.getText().toString();
        int nro1=Integer.parseInt(valor1);
        int nro2=Integer.parseInt(valor2);
        String select=spinner1.getSelectedItem().toString();
        if (select.equals("sumar")){
            int suma=nro1+nro2;
            String resu=String.valueOf(suma);
            tv1.setText(resu);
        }else{
            if(select.equals("restar")){
                int resta=nro1-nro2;
                String resu=String.valueOf(resta);
                tv1.setText(resu);
            }
            else{
                if(select.equals("multiplicar")){
                    int resta=nro1*nro2;
                    String resu=String.valueOf(resta);
                    tv1.setText(resu);
                }else{
                    if(select.equals("dividir")){
                        int resta=nro1/nro2;
                        String resu=String.valueOf(resta);
                        tv1.setText(resu);
                    }
                }
            }
        }
    }
    public void salir(View view){
        finish();
    }
}