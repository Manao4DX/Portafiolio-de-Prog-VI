package com.example.a2_pantallas;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.RadioButton;

public class RadioButon extends AppCompatActivity {

    private EditText pt1, pt2;
    private TextView tb1;
    private RadioButton bb1, bb2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio_buton);
        pt1=findViewById(R.id.pt1);
        pt2=findViewById(R.id.pt2);
        tb1=findViewById(R.id.tb1);
        bb1=findViewById(R.id.bb1);
        bb2=findViewById(R.id.bb2);
    }
    public void Operar (View view){

        String valor1 = pt1.getText().toString();

        String valor2 = pt2.getText().toString();

        int nro1 = Integer.parseInt(valor1);
        int nro2 = Integer.parseInt(valor2);

        if (bb1.isChecked() == true){

            int suma = nro1 + nro2;
            String resu = String.valueOf(suma);
            tb1.setText(resu);
        }
        else if (bb2.isChecked() == true){
            int resta = nro1 - nro2;
            String resu = String.valueOf(resta);
            tb1.setText(resu);
        }
    }
    public void salir(View view){
        finish();
    }
}