package com.example.a2_pantallas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Operaciones extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_operaciones);
    }
    public void extend(View view){
        Intent a = new Intent (this, extend.class);
        startActivity(a);
    }
    public void Spinn(View view){
        Intent a = new Intent (this, Spinn.class);
        startActivity(a);
    }
    public void CheckBox(View view){
        Intent a = new Intent (this, CheckBox.class);
        startActivity(a);
    }
    public void RadioButon(View view){
        Intent a = new Intent (this, RadioButon.class);
        startActivity(a);
    }

}