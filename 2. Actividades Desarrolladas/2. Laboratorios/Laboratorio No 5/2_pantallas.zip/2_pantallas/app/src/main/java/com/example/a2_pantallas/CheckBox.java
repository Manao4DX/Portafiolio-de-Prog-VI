package com.example.a2_pantallas;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class CheckBox extends AppCompatActivity {
    private EditText ep1, ep2;
    private TextView tp1;
    private android.widget.CheckBox rb1, rb2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_box2);

        ep1=findViewById(R.id.ep1);
        ep2=findViewById(R.id.ep2);
        tp1=findViewById(R.id.tp1);
        rb1=findViewById(R.id.rb1);
        rb2=findViewById(R.id.rb2);
    }
    public void Operar (View view){

        String valor1 = ep1.getText().toString();

        String valor2 = ep2.getText().toString();

        int nro1 = Integer.parseInt(valor1);
        int nro2 = Integer.parseInt(valor2);

        if (rb1.isChecked() == true){

            int suma = nro1 + nro2;
            String resu = String.valueOf(suma);
            tp1.setText(resu);
        }
        else if (rb2.isChecked() == true){
            int resta = nro1 - nro2;
            String resu = String.valueOf(resta);
            tp1.setText(resu);
        }
    }
    public void salir(View view){
        finish();
    }
}